package com.example.catapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private var allBtn: Button? = null
    private var favBtn: Button? = null
    private var allCats: TextView? = null
    private var favCats: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        getSupportActionBar()?.hide();
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        allBtn = findViewById(R.id.allButton)
        favBtn = findViewById(R.id.favButton)
        allCats = findViewById(R.id.allCts)
        favCats = findViewById(R.id.favCts)

        allBtn?.setOnClickListener{
            favCats?.visibility = View.INVISIBLE
            allCats?.visibility = View.VISIBLE
        }
        favBtn?.setOnClickListener{
            favCats?.visibility = View.VISIBLE
            allCats?.visibility = View.INVISIBLE
        }
    }
}